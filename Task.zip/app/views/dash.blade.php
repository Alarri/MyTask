<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Car Dash</title>
</head>
<body>
	<h1 style="text-align: center">Car Dash</h1>
  <hr>
  <div id="velocidad" style="min-width: 310px; max-width: 400px; height: 300px; margin: 0 auto"></div>
  {{HTML::script('js/jquery-2.0.3.min.js');}}
  {{HTML::script('js/highcharts.js');}}
  {{HTML::script('js/highcharts-more.js');}}
  {{HTML::script('js/exporting.js');}}
  {{HTML::script('js/dash.js');}}
</body>
</html>
